﻿// CoodinateMapper.cpp : コンソール アプリケーションのエントリ ポイントを定義します。
// This source code is licensed under the MIT license. Please see the License in License.txt.
// "This is preliminary software and/or hardware and APIs are preliminary and subject to change."
//

#define _CRT_SECURE_NO_WARNINGS
#include "stdafx.h"
#include <Windows.h>
#include <Kinect.h>
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <time.h> // to calculate time needed
#include <iostream>
#include <fstream>
#include <string>

FILE *fp;

#define PI 3.14159265359
#define SCI_PORT "\\\\.\\COM3"

//キネクト環境設定、°とmmで指定
#define KINECT_ELEV		30.0
#define KINECT_X		850
#define KINECT_Y		0
#define KINECT_Z		565

#define KINECT_FOV_X	70.0
#define KINECT_FOV_Y	60.0

#define DEPTH_THRETH	1800

int SCI(HWND hWnd);//シリアル通信
std::string SCI_pBufferRecieved;                        //受信した文字のバッファ
HANDLE hComPort;                                                        //シリアルポートのハンドル
HANDLE hSCI_Receive_Thread;                                        //受信スレッドのグローバル変数
OVERLAPPED sendOverlapped, recieveOverlapped;//「ReadFile()」「WriteFile()」を実行する時に「OVERLAPPED」を指定することが必須なので定義する
unsigned int dwThreadId;                                        //受信スレッドのID

template<class Interface>
inline void SafeRelease(Interface *& pInterfaceToRelease)
{
	if (pInterfaceToRelease != NULL){
		pInterfaceToRelease->Release();
		pInterfaceToRelease = NULL;
	}
}

void SCIInit(){
	//念のため初期化しておく(初期化しなかったからと言って特にエラーは確認していないが……)
	ZeroMemory(&sendOverlapped, sizeof(OVERLAPPED));
	ZeroMemory(&recieveOverlapped, sizeof(OVERLAPPED));

	// シリアルポートを開く
	//HANDLE hComPort;//グローバル変数として定義する
	hComPort = CreateFile(_T(SCI_PORT)
		, GENERIC_READ | GENERIC_WRITE
		, 0                                //オブジェクトを共有方法しない
		, NULL                        // セキュリティ属性デフォルト//ハンドルを子プロセスへ継承することを許可するかどうか//NULLは継承できない
		, OPEN_EXISTING        //ファイルを開きます。指定したファイルが存在していない場合、この関数は失敗します。
		, FILE_FLAG_OVERLAPPED//0//FILE_FLAG_OVERLAPPEDは、非同期であることを意味する。//同期とは、この関数を実行すると処理が完了するまで待たされる。非同期とはCPUの空き時間を使って関数が処理される
		//良く分からないのだけれど、FILE_FLAG_OVERLAPPEDを設定すると送信が上手く行われていない気がする……。
		//⇒「FILE_FLAG_OVERLAPPED」を指定した場合は「ReadFile()」「WriteFile()」を実行する時に「OVERLAPPED」を指定することが必須。しないとバグる。
		, NULL
		); // シリアルポートを開く

	if (hComPort == INVALID_HANDLE_VALUE){
		OutputDebugString(_T("ポートが開きません"));
	}

	/*//必要があれば指定する//指定しなかった場合はデフォルトの容量が指定される
	//送受信バッファの容量の指定
	SetupComm(        hComPort,        // 通信デバイスのハンドル：CreateFile()で取得したハンドルを指定
	1024,                // 受信バッファのサイズ  ：受信のバッファーサイズをバイト単位で指定
	1024                // 送信バッファのサイズ  ：送信のバッファーサイズをバイト単位で指定
	);
	*/

	//バッファの初期化
	//指定した通信資源の出力バッファまたは入力バッファにあるすべての文字を破棄します。未処理の読み取り操作または書き込み操作を中止することもできます。
	PurgeComm(hComPort, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);//無くても動くけど、まあ一応初期化しておく。


	//通信の設定
	DCB dcb; // シリアルポートの構成情報が入る構造体
	GetCommState(hComPort, &dcb); // 現在の設定値を読み込み // DCB 構造体のメンバの一部だけを設定する場合でも、他のメンバも適切な値にするため、GetCommState 関数を使っていったん DCB 構造体を設定してから、該当するメンバの値を修正するようにします。(msdn) // つまり全て設定する場合は不要ではあるが、安全のために一度読み込んでおく？(今回は一部しか設定しないので必要)

	dcb.BaudRate = 19200; // 速度
	dcb.ByteSize = 8; // データ長
	dcb.Parity = NOPARITY; // パリティ
	dcb.StopBits = ONESTOPBIT; // ストップビット長
	dcb.fOutxCtsFlow = FALSE; // 送信時CTSフロー
	dcb.fRtsControl = RTS_CONTROL_DISABLE;//RTS_CONTROL_ENABLE; // RTSフロー // なし
	dcb.EvtChar = NULL;//つまり「\0」に同じ//ここで指定した文字列を受信した時「EV_RXFLAG」イベントが発生する。

	SetCommState(hComPort, &dcb); // 変更した設定値を書き込み

	/*//必要があれば設定する。//指定しなかった場合はデフォルトの容量が指定される
	// シリアルポートのタイムアウト状態操作
	COMMTIMEOUTS cto;
	GetCommTimeouts( hComPort, &cto ); // タイムアウトの設定状態を取得
	cto.ReadIntervalTimeout = 1000;
	cto.ReadTotalTimeoutMultiplier = 0;
	cto.ReadTotalTimeoutConstant = 1000;
	cto.WriteTotalTimeoutMultiplier = 0;
	cto.WriteTotalTimeoutConstant = 0;
	SetCommTimeouts( hComPort, &cto ); // タイムアウトの状態を設定
	*/
}

#define SETEND '|'
#define SETEND2 '/'
unsigned char crc_calc_t(void* data, int byte){
	static unsigned char *data2, crc, temp, inv;
	int i, j;

	data2 = (unsigned char*)malloc(byte);
	for (i = 0; i < byte; i++){
		data2[i] = ((unsigned char*)data)[i];
	}
	crc = 0;
	for (j = 0; j < byte; j++){
		for (i = 0; i < 8; i++){
			inv = (data2[j] >> (7 - i)) ^ (crc >> 7);
			inv = inv & 0x01;
			inv += inv * 6;
			crc = crc << 1;
			temp = crc;
			temp = temp ^ inv;
			temp = temp & 0x06;
			crc = crc & 0xf8;
			crc += temp;
			temp = inv & 0x01;
			crc += temp;
			//crc = ((crc << 1) & 0xf8) + ((crc << 1) ^ (inv & 0x06)) + (inv & 0x01);
		}
	}
	free(data2);

	if (crc == SETEND || crc == SETEND2)	//区切り文字との混同を防ぐ
		crc++;
	return crc;
}

void DataSend(cv::Point3i worldPos){
	UINT16 x = (UINT16)worldPos.x, y = (UINT16)worldPos.y;
	unsigned char sendChar[10];
	sendChar[0] = x >> 8;
	sendChar[1] = x;
	sendChar[2] = y >> 8;
	sendChar[3] = y;	
	sendChar[4] = crc_calc_t((unsigned char*)sendChar, 4);
	sendChar[5] = '|';
	sendChar[6] = '|';
	DWORD SCI_LengthOfPutOrRecieved;
	WriteFile(hComPort, &sendChar, sizeof(char) * 7, &SCI_LengthOfPutOrRecieved, &sendOverlapped); // ポートへ送信//「length()」は文字の終わりを表すNULL「\0」を文字の長さとして扱わないので「+1」しておく
}

#define G (9797.4)
#define M (6.4)
#define K (0.002266)
#define dT (0.002)
#define fvr(t,vr,vz,r,z) (-K*(vr)*sqrt((vr)*(vr)+(vz)*(vz))/M)
#define fvz(t,vr,vz,r,z) (-G-K*(vz)*sqrt((vr)*(vr)+(vz)*(vz))/M)
#define fr(t,vr,vz,r,z) (vr)
#define fz(t,vr,vz,r,z) (vz)
cv::Point3d yosoku1(cv::Point3d p1, cv::Point3d p2, double deltat, double dt, double m, double k){
	double theta, r, or, z, oz, vr, vz, st;
	double vzk[4], vrk[4], rk[4], zk[4];
	static UINT8 cnt = 0;
	char fn[20];
	cv::Point3d point;

	vz = (p2.z - p1.z) / deltat;
	vr = sqrt((p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y)) / deltat;
	theta = atan2(p2.y - p1.y, p2.x - p1.x);
	z = oz = p2.z;
	r = or = 0;
	st = 0;
	sprintf(fn, "yosoku%d.csv", cnt);
	//fopen_s(&fp,fn, "w");
	while (1){
		//fprintf(fp, "%f,%f,%f,%f,%f\n", st, vr, vz, r, z);

		vrk[0] = dt*fvr(st, vr, vz, r, z);
		vzk[0] = dt*fvz(st, vr, vz, r, z);
		rk[0] = dt*fr(st, vr, vz, r, z);
		zk[0] = dt*fz(st, vr, vz, r, z);
		vrk[1] = dt*fvr(st + dt / 2, vr + vrk[0] / 2, vz + vzk[0] / 2, r + rk[0] / 2, z + zk[0] / 2);
		vzk[1] = dt*fvz(st + dt / 2, vr + vrk[0] / 2, vz + vzk[0] / 2, r + rk[0] / 2, z + zk[0] / 2);
		rk[1] = dt*fr(st + dt / 2, vr + vrk[0] / 2, vz + vzk[0] / 2, r + rk[0] / 2, z + zk[0] / 2);
		zk[1] = dt*fz(st + dt / 2, vr + vrk[0] / 2, vz + vzk[0] / 2, r + rk[0] / 2, z + zk[0] / 2);
		vrk[2] = dt*fvr(st + dt / 2, vr + vrk[1] / 2, vz + vzk[1] / 2, r + rk[1] / 2, z + zk[1] / 2);
		vzk[2] = dt*fvz(st + dt / 2, vr + vrk[1] / 2, vz + vzk[1] / 2, r + rk[1] / 2, z + zk[1] / 2);
		rk[2] = dt*fr(st + dt / 2, vr + vrk[1] / 2, vz + vzk[1] / 2, r + rk[1] / 2, z + zk[1] / 2);
		zk[2] = dt*fz(st + dt / 2, vr + vrk[1] / 2, vz + vzk[1] / 2, r + rk[1] / 2, z + zk[1] / 2);
		vrk[3] = dt*fvr(st + dt, vr + vrk[2], vz + vzk[2], r + rk[2], z + zk[2]);
		vzk[3] = dt*fvz(st + dt, vr + vrk[2], vz + vzk[2], r + rk[2], z + zk[2]);
		rk[3] = dt*fr(st + dt, vr + vrk[2], vz + vzk[2], r + rk[2], z + zk[2]);
		zk[3] = dt*fz(st + dt, vr + vrk[2], vz + vzk[2], r + rk[2], z + zk[2]);
		vr += (vrk[0] + 2 * vrk[1] + 2 * vrk[2] + vrk[3]) / 6;
		vz += (vzk[0] + 2 * vzk[1] + 2 * vzk[2] + vzk[3]) / 6;
		r += (rk[0] + 2 * rk[1] + 2 * rk[2] + rk[3]) / 6;
		z += (zk[0] + 2 * zk[1] + 2 * zk[2] + zk[3]) / 6;

		st = st + dt;
		if (z <= 0){
			//fprintf(fp, "%f,%f,%f,%f,%f\n", st, vr, vz, r, z);
			r = or - oz*(or - r) / (oz - z);
			z = 0;

			point.x = r*cos(theta) + p2.x;
			point.y = r*sin(theta) + p2.y;
			point.z = 0;
			break;
		}
		oz = z;
		or = r;
	}
	cnt++;
	//fclose(fp);
	return point;
}
cv::Point3d pos;
cv::Point3d vel;
/*
cv::Point3i PosPrediction(cv::Point3i oldPos, cv::Point3i curPos, int dt){
	double t = 0;
	pos.x = curPos.x;
	pos.y = curPos.y;
	pos.z = curPos.z;
	if ((oldPos.z - curPos.z) <= 0.0)
		return pos;
	vel.x = (double)(curPos.x - oldPos.x) / (oldPos.z - curPos.z);	//[mm/33ms] = [m/s]*30
	vel.y = (double)(curPos.y - oldPos.y) / (oldPos.z - curPos.z);
	pos.x = oldPos.x + vel.x* pos.z;
	pos.y = oldPos.y + vel.y* pos.z;
	pos.z = 0;
	return pos;
}*/
cv::Point3i PosPrediction(cv::Point3i oldPos, cv::Point3i curPos, int dt){
	double t = 0;
	pos = yosoku1(oldPos, curPos, (double)dt/1000.0, 0.002, M, K);
	/*pos.x = curPos.x;
	pos.y = curPos.y;
	pos.z = curPos.z;
	if ((oldPos.z - curPos.z) <= 0.0)
		return pos;
	vel.x = (double)(curPos.x - oldPos.x) / (oldPos.z - curPos.z);	//[mm/33ms] = [m/s]*30
	vel.y = (double)(curPos.y - oldPos.y) / (oldPos.z - curPos.z);
	pos.x = oldPos.x + vel.x* pos.z;
	pos.y = oldPos.y + vel.y* pos.z;
	pos.z = 0;*/
	return pos;
}
/*
void PosPrediction(cv::Point3i oldPos, cv::Point3i curPos){
	double velSum, k=0.002266, grav=9.8;
	cv::Point3d vel;
	cv::Point3d acc,pos;
	pos.x = curPos.x;
	pos.y = curPos.y;
	pos.z = curPos.z;
	vel.x = curPos.x - oldPos.x;	//[mm/33ms] = [m/s]*30
	vel.y = curPos.y - oldPos.y;
	vel.z = curPos.z - oldPos.z;
	velSum = sqrt(vel.x*vel.x + vel.y*vel.y + vel.z*vel.z);
	acc.x = k*velSum*vel.x/33;	//[mm/ms^2]
	acc.y = k*velSum*vel.y/33;
	acc.z = (k*velSum*vel.z-grav*30)/33;
	for (UINT8 t=0; pos.z > 0; t++){
		vel.z = vel.z + 5*t*acc.z;
		pos.z = poz.z + vel.z;
	}
}*/



//キネクトの3次元極座標系をマシンのシャトルレシーブ位置を原点とした直交座標系に
cv::Point3i CalcWorldPosition(cv::Point3i rawPos)
{
	double theta, phi;
	int rad;
	cv::Point3i worldPos;
	theta = (90 + (double)rawPos.y / 424.0 * KINECT_FOV_Y - KINECT_ELEV) / 180.0 * PI;
	phi = (double)rawPos.x / 512.0 * KINECT_FOV_X / 180.0 * PI;
	rad = rawPos.z;
	worldPos.x = rad*sin(theta)*cos(phi) + KINECT_X;
	worldPos.y = rad*sin(theta)*sin(phi) + KINECT_Y;
	worldPos.z = rad*cos(theta) + KINECT_Z;

	return worldPos;
}

void ColorScaleBCGYR(double in_value,uchar* out_val)
{
	// 0.0～1.0 の範囲の値をサーモグラフィみたいな色にする
	// 0.0                    1.0
	// 青    水    緑    黄    赤
	// 最小値以下 = 青
	// 最大値以上 = 赤
	int ret;
	int a = 255;    // alpha値
	int r, g, b;    // RGB値
	double  value = in_value;
	double  tmp_val = cos(4 * 3.1418 * value);
	int     col_val = (int)((-tmp_val / 2 + 0.5) * 255);
	if (value >= (4.0 / 4.0)) { r = 255;     g = 0;       b = 0; }   // 赤
	else if (value >= (3.0 / 4.0)) { r = 255;     g = col_val; b = 0; }   // 黄～赤
	else if (value >= (2.0 / 4.0)) { r = col_val; g = 255;     b = 0; }   // 緑～黄
	else if (value >= (1.0 / 4.0)) { r = 0;       g = 255;     b = col_val; }   // 水～緑
	else if (value >= (0.0 / 4.0)) { r = 0;       g = col_val; b = 255; }   // 青～水
	else { r = 0;       g = 0;       b = 255; }   // 青
	out_val[0] = b; out_val[1] = g; out_val[2] = r;
	/*ret = (a & 0x000000FF) << 24
		| (r & 0x000000FF) << 16
		| (g & 0x000000FF) << 8
		| (b & 0x000000FF);
	return ret;*/
}



int _tmain(int argc, _TCHAR* argv[])
{
	
	cv::setUseOptimized(true);

	SCIInit();

	// Sensor
	IKinectSensor* pSensor;
	HRESULT hResult = S_OK;
	hResult = GetDefaultKinectSensor(&pSensor);
	if (FAILED(hResult)){
		std::cerr << "Error : GetDefaultKinectSensor" << std::endl;
		return -1;
	}

	hResult = pSensor->Open();
	if (FAILED(hResult)){
		std::cerr << "Error : IKinectSensor::Open()" << std::endl;
		return -1;
	}

	// Source
	IDepthFrameSource* pDepthSource;
	hResult = pSensor->get_DepthFrameSource(&pDepthSource);
	if (FAILED(hResult)){
		std::cerr << "Error : IKinectSensor::get_DepthFrameSource()" << std::endl;
		return -1;
	}

	// Reader
	IDepthFrameReader* pDepthReader;
	hResult = pDepthSource->OpenReader(&pDepthReader);
	if (FAILED(hResult)){
		std::cerr << "Error : IDepthFrameSource::OpenReader()" << std::endl;
		return -1;
	}

	// Description
	IFrameDescription* pDepthDescription;
	hResult = pDepthSource->get_FrameDescription(&pDepthDescription);
	if (FAILED(hResult)){
		std::cerr << "Error : IDepthFrameSource::get_FrameDescription()" << std::endl;
		return -1;
	}

	int depthWidth = 0;
	int depthHeight = 0;
	pDepthDescription->get_Width(&depthWidth); // 512
	pDepthDescription->get_Height(&depthHeight); // 424
	unsigned int depthBufferSize = depthWidth * depthHeight * sizeof(unsigned short);

	cv::Mat depthBufferMat(depthHeight, depthWidth, CV_16U);
	cv::Mat depthMat(depthHeight, depthWidth, CV_8UC1);
	cv::Mat depthColor(depthHeight, depthWidth, CV_8UC4);
	cv::namedWindow("Color");

	unsigned short minDepth, maxDepth;
	pDepthSource->get_DepthMinReliableDistance(&minDepth);
	pDepthSource->get_DepthMaxReliableDistance(&maxDepth);

	cv::Point3i radPos,ballPos[2],finPos;

	clock_t  startms, endms, frameTime[2] = { 0 };

	int save=0,counter=0,frameCnt=0;
	char cntText[20];
	cv::createTrackbar("SAVE", "Color", &save, 1);

	// ファイル出力ストリームの初期化
	std::ofstream ofs("nazo.txt");

	while (1){
		startms = clock();

		// Depth Frame
		IDepthFrame* pDepthFrame = nullptr;
		hResult = pDepthReader->AcquireLatestFrame(&pDepthFrame);
		if (SUCCEEDED(hResult)){
			hResult = pDepthFrame->AccessUnderlyingBuffer(&depthBufferSize, reinterpret_cast<UINT16**>(&depthBufferMat.data));
			if (SUCCEEDED(hResult)){
				depthBufferMat.convertTo(depthMat, CV_8U, -255.0f / 8000.0f, 255.0f);
				//cv::cvtColor(depthMat, depthColor, CV_GRAY2RGB);
			}
		}
		//SafeRelease( pDepthFrame );

		// Mapping (Depth to Color) & Pseudocolor for Depth
		UINT16 depth, depthX=0, depthY=0,xx,yy,dd,cc;
		UINT32 count = 0,ii;
		double sumX = 0, sumY = 0, sumD = 0;
		uchar bgr[3];
		cv::Mat e = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
		if (SUCCEEDED(hResult)){
			depthColor = cv::Scalar(0, 0, 0, 0);
			for (int i = 0; i < depthBufferMat.total(); ++i){
				int destIndex = i * 4;
				depthX++;
				if (depthX == depthWidth){
					depthX = 0;
					depthY++;
				}

				depth = reinterpret_cast<UINT16*>(depthBufferMat.data)[i];

				if (depth > 8000 || depth == 0){
					depthColor.data[destIndex + 0] = 255;
					depthColor.data[destIndex + 1] = 255;
					depthColor.data[destIndex + 2] = 255;
				}
				else{
					ColorScaleBCGYR((double)(depth - 500) / 7500.0, bgr);
					depthColor.data[destIndex + 0] = bgr[2];
					depthColor.data[destIndex + 1] = bgr[1];
					depthColor.data[destIndex + 2] = bgr[0];

					if (depth < DEPTH_THRETH){
						cc = 0;
						if (depthX != 0 && depthY != 0 && depthX != depthWidth - 1 && depthY != depthHeight - 1){
							for (yy = depthY - 1; yy <= depthY + 1; yy++){
								for (xx = depthX - 1; xx <= depthX + 1; xx++){

									ii = yy*depthWidth + xx;
									dd = reinterpret_cast<UINT16*>(depthBufferMat.data)[ii];
									if (dd != 0 && dd < DEPTH_THRETH)
										cc++;
								}
							}
							if (cc > 7){
								sumX += (depthX - depthWidth / 2);
								sumY += (depthY - depthHeight / 2);
								sumD += depth;
								count++;
							}
						}
					}
				}
			}

			if (count > 0){
				radPos.x = (int)(sumX / (double)count);
				radPos.y = (int)(sumY / (double)count);
				radPos.z = (int)(sumD / (double)count);
				frameCnt++;
				ballPos[1] = ballPos[0];
				frameTime[1] = frameTime[0];
				ballPos[0] = CalcWorldPosition(radPos);
				frameTime[0] = startms;
				
				if (frameTime[1] != 0 && frameTime[0] - frameTime[1] < 100)
					finPos = PosPrediction(ballPos[1], ballPos[0], (int)(frameTime[0] - frameTime[1]));
				else{
					finPos.x = 0;  finPos.y = 0;
				}
				if (finPos.x != 0 && finPos.y != 0)
					DataSend(finPos);
				ofs << ballPos[0].x << "," << ballPos[0].y << "," << ballPos[0].z << "," << finPos.x << "," << finPos.y << "," << finPos.z << std::endl;
				std::cerr << finPos.x << "," << finPos.y << std::endl;
				
			}
			else{
				if (frameCnt != 0)
					counter++;
				frameCnt = 0;
				radPos.x = 0;
				radPos.y = 0;
				radPos.z = 0;

			}
			
			std::string pos = std::to_string(ballPos[0].x) + ", " + std::to_string(ballPos[0].y) + ", " + std::to_string(ballPos[0].z);
			cv::putText(depthColor, pos, cv::Point(0, 20), cv::FONT_HERSHEY_COMPLEX_SMALL,1.0, CV_RGB(0, 0, 0),2);
			cv::putText(depthColor, pos, cv::Point(0, 20), cv::FONT_HERSHEY_COMPLEX_SMALL, 1.0, CV_RGB(255, 255, 255),1);
			cv::circle(depthColor, cv::Point(radPos.x + depthWidth / 2, radPos.y + depthHeight / 2), 3, CV_RGB(0, 0, 0));
			cv::circle(depthColor, cv::Point(radPos.x + depthWidth / 2, radPos.y + depthHeight / 2), 2, CV_RGB(255, 255, 255));

			SafeRelease(pDepthFrame);

			cv::imshow("Color", depthColor);

			if (save){
				std::string name = std::to_string(counter) + "_" + std::to_string(frameCnt) + ".jpg";
				cv::imwrite(name, depthColor);
			}
			depthColor = cv::Mat::zeros(depthHeight, depthWidth, CV_8UC4);

			endms = clock();
			//std::cerr << (int)endms - startms << std::endl;
		}
		if (!save)
			counter = 0;
		
		if (cv::waitKey(1) == VK_ESCAPE){
			break;
		}
	}

	SafeRelease(pDepthSource);
	SafeRelease(pDepthReader);
	SafeRelease(pDepthDescription);
	if (pSensor){
		pSensor->Close();
	}
	SafeRelease(pSensor);
	cv::destroyAllWindows();

	return 0;
}

